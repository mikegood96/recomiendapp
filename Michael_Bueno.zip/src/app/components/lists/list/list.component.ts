import {Component, Input, OnInit} from '@angular/core';

import {ListService} from '../list.service';
import {ListI} from '../../../shared/models/list.interface';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss']
})
export class ListComponent implements OnInit {

  @Input() list: ListI;
  constructor( private listSvc: ListService) { }

  ngOnInit() {
  }

}
