import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ListService} from '../../lists/list.service';
import {ListI} from '../../../shared/models/list.interface';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public lists$: Observable<ListI[]>;

  constructor(private listSvc: ListService) { }

  ngOnInit() {
    this.listSvc.getAllLists().subscribe(lists => console.log('LISTS', lists));
    this.lists$ = this.listSvc.getAllLists();
  }

}
