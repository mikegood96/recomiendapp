import {Component, Input, OnInit} from '@angular/core';
import {AuthService} from '../../../shared/services/auth.service';
import {ListService} from '../../lists/list.service';
import {Observable} from 'rxjs';
import * as $ from 'jquery';
import {ListI} from '../../../shared/models/list.interface';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  filterList: any;
  categoryList: any;
  public lists$: Observable<ListI[]>;

  constructor(private authSvc: AuthService, private listSvc: ListService) { }

  ngOnInit() {
    this.lists$ = this.listSvc.getAllLists();
  }

  onLogOut(): void {
    this.authSvc.logOut();
  }

  showMenu() {
    const e = $('#showMenu');

    if (e.hasClass('hide')) {
      e.addClass('show');
      e.removeClass('hide');
    } else {
      e.addClass('hide');
      e.removeClass('show');
    }

  }

}
