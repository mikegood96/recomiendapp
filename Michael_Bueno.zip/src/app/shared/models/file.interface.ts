export interface FileI {
  name:string;
  image: File;
  size: string;
  type: string;
}
