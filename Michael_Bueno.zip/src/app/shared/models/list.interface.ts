export interface ListI {
  titleList: string;
  contentList: string;
  imageList?: any;
  id?: string;
  tagsList: string;
  fileRef ?: string;
  userUid?: string;
}
