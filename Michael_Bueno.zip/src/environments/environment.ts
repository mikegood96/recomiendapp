// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: 'AIzaSyDCEQ8KL3SYUTxXkJE9vYT9NfcwRxUORjQ',
    authDomain: 't1-recomiendapp.firebaseapp.com',
    databaseURL: 'https://t1-recomiendapp.firebaseio.com',
    projectId: 't1-recomiendapp',
    storageBucket: 't1-recomiendapp.appspot.com',
    messagingSenderId: '570473138504',
    appId: '1:570473138504:web:d307896a300845d0bc0b7d'
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
