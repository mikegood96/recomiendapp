export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: 'AIzaSyDCEQ8KL3SYUTxXkJE9vYT9NfcwRxUORjQ',
    authDomain: 't1-recomiendapp.firebaseapp.com',
    databaseURL: 'https://t1-recomiendapp.firebaseio.com',
    projectId: 't1-recomiendapp',
    storageBucket: 't1-recomiendapp.appspot.com',
    messagingSenderId: '570473138504',
    appId: '1:570473138504:web:d307896a300845d0bc0b7d'
  }
};
